for i in range(int(input())):
    n = int(input())
    nth= n*(2*n+1)
    print(nth)