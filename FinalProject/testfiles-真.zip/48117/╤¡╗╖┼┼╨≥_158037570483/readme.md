### 题目描述

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BE%AA%E7%8E%AF%E6%8E%92%E5%BA%8F.png" alt="Sample"  width="800" height="115">
</p>

### 输入描述

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BE%AA%E7%8E%AF%E6%8E%92%E5%BA%8F2.png" alt="Sample"  width="360" height="36">
</p>

### 输出描述
<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BE%AA%E7%8E%AF%E6%8E%92%E5%BA%8F3.png" alt="Sample"  width="530" height="80">
</p>


### 测试样例
#### 样例1: 输入-输出-解释
```
5 5
3 2 3 1 1
```
```
1
5
1 4 2 3 5
```
```
你可以用两次操作1-4-1和2-3-5-2排序数组，但这样会 WA，因为你的任务是最小化q，而最优解的q=1。
一种可行的方法是1-4-2-3-5-1，即样例输出。
```
### 题目来源  
`eJOI`