## 题目描述
<p>实现一个基本的计算器来计算一个简单的字符串表达式的值。</p>

<p>字符串表达式可以包含左括号&nbsp;<code>(</code>&nbsp;，右括号&nbsp;<code>)</code>，加号&nbsp;<code>+</code>&nbsp;，减号&nbsp;<code>-</code>，<strong>非负</strong>整数和空格&nbsp;<code>&nbsp;</code>。</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> "1 + 1"
<strong>输出:</strong> 2
</pre>

<p><strong>示例 2:</strong></p>

<pre><strong>输入:</strong> " 2-1 + 2 "
<strong>输出:</strong> 3</pre>

<p><strong>示例 3:</strong></p>

<pre><strong>输入:</strong> "(1+(4+5+2)-3)+(6+8)"
<strong>输出:</strong> 23</pre>

<p><strong>说明：</strong></p>

<ul>
	<li>你可以假设所给定的表达式都是有效的。</li>
	<li>请<strong>不要</strong>使用内置的库函数 <code>eval</code>。</li>
</ul>